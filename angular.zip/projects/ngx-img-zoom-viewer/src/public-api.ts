/*
 * Public API Surface of ngx-img-zoom-viewer
 */

export * from './lib/ngx-img-zoom-viewer.component';
export * from './lib/ngx-img-zoom-viewer.module';
